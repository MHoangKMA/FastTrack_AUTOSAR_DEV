 /*
 * filename: TestSuiteLib.h
 *
 *  Created on: Sep 05, 2024
 *      Author: Hoang Tran-Minh 
 *      Mail: HoangTM17@fpt.com
 */

#ifndef _TESTSUITELIB_H_
#define _TESTSUITELIB_H_
/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <gtest/gtest.h>

#ifdef __cplusplus
extern "C"
{
#endif

#include "../../API/inlcude/APILib.h"
#include <stdlib.h>

#ifdef __cplusplus

}
#endif

#endif /* _TESTSUITELIB_H_*/
 /******************************************************************************
 * EOF
 ******************************************************************************/