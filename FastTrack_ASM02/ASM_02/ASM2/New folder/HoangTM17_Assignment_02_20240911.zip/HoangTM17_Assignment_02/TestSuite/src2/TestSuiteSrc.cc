 /*
 * filename: TestSuiteSrc.cc
 *
 *  Created on: Sep 05, 2024
 *      Author: Hoang Tran-Minh 
 *      Mail: HoangTM17@fpt.com
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "../../Testsuite/include2/TestSuiteLib.h"

/*******************************************************************************
 * Testcase 01: TEST(TestSuiteAssignment_02, TestCase_01_ReverseStringTest)
 ******************************************************************************/
/**
* @brief          Test case for checking if a string is the reverse of another string.
* @details        This test case verifies if the `checkStringReverse` function correctly identifies 
*                 whether the second string is the reverse of the first string. It uses a sample 
*                 original string and its expected reversed string to validate the function's correctness.
*
* @pre            The function `checkStringReverse` is implemented and available for use.
* @post           Validates if the reversed string matches the expected result.
*
* @test_level     Automation Framework Testing
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                   - Define the original string `strOriginal`.
*                   - Define the expected reversed string `strReverse`.
*                   - Call `checkStringReverse` with these strings.
*                   - Verify that the return value is `TRUE` indicating a match.
* @pass_criteria  The test passes if `checkStringReverse` returns `TRUE` for the given inputs.
*
* @requirements   N/A
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @defects        N/A
* @test_priority  High
* @note           Ensure that the `checkStringReverse` function is correctly implemented and linked.
* @keywords       String, Reverse, Check
*/
TEST(TestSuiteAssignment_02, TestCase_01_ReverseStringTest)
{
    /* Original string to be reversed */
    const char *strOriginal = "automation testing";
    
    /* Expected reversed string */
    const char *strReverse = "gnitset nnntamotua";
    //const char *strReverse = "gnitset noitamotua"; 

    /* Verify if the reversed string matches the expected result using checkStringReverse function */
    /* @step KEY VERIFICATION POINT: EXPECT_TRUE() expects return is TRUE */
    EXPECT_TRUE(checkStringReverse(strOriginal, strReverse));
}

/*******************************************************************************
 * Testcase 02: TEST(TestSuiteAssignment_02, TestCase_02_PrimeNumberTest)
 ******************************************************************************/
/**
 * @brief       Generates an array of unique prime numbers.
 * @details     This function generates random unique prime numbers and stores 
 *              them in the provided array.
 *              The function uses a random number generator and checks for both 
 *              primality and uniqueness.
 * 
 * @param[inout] array Pointer to the array where unique prime numbers will be stored.
 * @param[in]    size  The size of the array (number of unique prime numbers to generate).
 * 
 * @pre         The array provided must have enough memory allocated to store the desired 
 *              number of unique prime numbers.
 * 
 * @post        The array will be filled with `size` unique prime numbers.
 * 
 * @requirements N/A
 * @traceability_id N/A
 * @traceability N/A
 * 
 * @execution_type Automated
 * @pass_criteria The function successfully fills the array with 
 *                       unique prime numbers without duplicates.
 * 
 * @example
 * @code
 *    uint8_t primes[10];
 *    generateUniquePrimeNumbers(primes, 10);
 * @endcode
 */
TEST(TestSuiteAssignment_02, TestCase_02_PrimeNumberTest)
{
    /* Array to store 10 unique random numbers */
    uint8_t numbersArrayTest[10] = {0U}; 

    /* Generate 10 unique random numbers */
    generateUniqueRandomNumbers(numbersArrayTest, sizeof(numbersArrayTest) / sizeof(numbersArrayTest[0]));

    /* Check if each number in numbersArrayTest is a prime number */
    for (size_t i = 0; i < sizeof(numbersArrayTest) / sizeof(numbersArrayTest[0]); ++i)
    {
        /* Check if the current number is a prime number */
        bool isPrime = checkPrimeNumber(numbersArrayTest[i]);

        /* Expect that the number is a prime number */
        /* @step KEY VERIFICATION POINT: Expect that the number is a prime number */
        EXPECT_TRUE(isPrime) << "Number " << (int)numbersArrayTest[i] << " is not prime";
    }
}

 /******************************************************************************
 * EOF
 ******************************************************************************/

