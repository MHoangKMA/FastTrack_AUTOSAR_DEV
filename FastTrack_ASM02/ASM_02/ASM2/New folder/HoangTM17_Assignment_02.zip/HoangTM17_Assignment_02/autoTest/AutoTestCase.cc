#include <gtest/gtest.h>

#ifdef __cplusplus
extern "C"
{
#endif

#include "../include/AutoTestLib.h"
#include <stdlib.h>

#ifdef __cplusplus

}
#endif

TEST(TestSuite, TestCase_01_ReverseStringTest)
{
    const char *strOriginal = "automation testing";
    //const char *strReverse = "gnitset nnnitamotua";
    const char *strReverse = "gnitset nnnoitamotua";

    EXPECT_TRUE(checkStringReverse(strOriginal, strReverse));
}

TEST(TestSuite, TestCase_02_PrimeNumberTest)
{
    srand(time(0));
    uint8_t numbersTest[10] = {0U};
    bool used[101] = {false};  // Đảm bảo dùng số từ 1 đến 100
    uint8_t indexArray = 0U;

    for(indexArray = 0; indexArray < 10; ++indexArray)
    {
        do
        {
            numbersTest[indexArray] = rand() % 100 + 1;
        } while (used[numbersTest[indexArray]]);
        used[numbersTest[indexArray]] = true;
    }

    for(indexArray = 0U; indexArray < sizeof(numbersTest) / sizeof(numbersTest[0]); ++indexArray)
    {
        printf("Testing number: %d\n", numbersTest[indexArray]); 
        EXPECT_TRUE(checkPrimeNumber(numbersTest[indexArray]));
    }
}
