

#ifndef _AUTOTESTLIB_H_
#define _AUTOTESTLIB_H_

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
typedef enum
{
    FALSE = 0U,
    TRUE = 1U
} Ret_Val_e;

Ret_Val_e checkStringReverse(const char *originalStr, const char *reverseStr);
Ret_Val_e checkPrimeNumber(uint8_t number);

#endif /* _AUTOTESTLIB_H_*/