#include "../include/AutoTestLib.h"

Ret_Val_e checkStringReverse(const char *originalStr, const char *reverseStr)
{
    uint8_t originalStrLen = strlen(originalStr);
    uint8_t reverseStrLen  = strlen(reverseStr);
    uint8_t indexCount = 0U;
    Ret_Val_e retValue = TRUE;

    if(originalStrLen != reverseStrLen)
    {
        return FALSE;
    }
    else
    {

    }

    for(indexCount = 0U; indexCount < originalStrLen; ++indexCount)
    {
        if(originalStr[indexCount] != reverseStr[originalStrLen - 1u - indexCount])
        {
            return FALSE;
        }
    }

    return retValue;
}

Ret_Val_e checkPrimeNumber(uint8_t number)
{
    uint8_t l_divisor = 0U;
    Ret_Val_e retValue = TRUE;

    if(number <= 1U)
    {
        return FALSE;
    }
    else
    {

    }

    if(number == 2U)
    {
        return TRUE;
    }
    else
    {

    }

    if( (number % 2U) == 0U)
    {
        return FALSE;
    }
    else
    {

    }

    for(l_divisor = 3U; (l_divisor * l_divisor) <= number; l_divisor += 2U)
    {
        if( (number % l_divisor) == 0U)
        {
            return FALSE;
        }     
    }
    return retValue;

}